<div class="sidebar-nav-wrapper" id="sidebar-wrapper">
		<ul class="sidebar-nav">
			<li>
				<a href="tute-issuer-dashboard.php"><i class="fa fa-home menu-icon"></i> HOME</a>
			</li>
			<li class="dropdown">
				<a href= "#" class="dropdown-toggle" data-toggle="dropdown">
				 	<i class="fa fa-file-code-o menu-icon"></i>STUDENT ATTENDANCE <span class="caret"></span>
				</a>
				<ul class="dropdown-menu">
					<li>
						<a href="mark-attendance-subject-select.php"><i class="fa fa-caret-right"></i>MARK</a>
					</li>
					<li>
						<a href="view-student-attendance.php"><i class="fa fa-caret-right"></i>VIEW</a>
					</li>
				</ul>
                <div class="clearfix"></div>
			</li>
			<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<i class="fa fa-file-code-o menu-icon"></i> TUTES <span class="caret"></span>
				</a>
				<ul class="dropdown-menu">
					<li>							
						<a href="mark-tute-select.php"><i class="fa fa-caret-right"></i> MARK</a>
					</li>
                    <li>
						<a href="issued-tutes.php"><i class="fa fa-caret-right"></i> ISSUED  </a>
					</li>
					<li>							
						<a href="add-student-tute.php"><i class="fa fa-caret-right"></i>ADD</a>
					</li>
					<li>
						<a href="view-tutes.php"><i class="fa fa-caret-right"></i> VIEW</a>
					</li>
				</ul>						
			</li>
		</ul>
</div>