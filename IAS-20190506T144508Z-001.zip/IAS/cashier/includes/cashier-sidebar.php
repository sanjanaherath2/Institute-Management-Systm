<div class="sidebar-nav-wrapper" id="sidebar-wrapper">
				<ul class="sidebar-nav">
                        <li>
                            <a href="cashier-dashboard.php"><i class="fa fa-home menu-icon"></i> HOME</a>
                        </li>
                        <li>
                            <a href="cashier-student-list.php"><i class="fa fa-money menu-icon"></i> STUDENT FEES</a>
                        </li>
                        <li>
                            <a href="cashier-lecturer-list.php"><i class="fa fa-money menu-icon"></i> LECTURER PAYMENTS</a>
                        </li>						
                        <li>
                            <a href="cashier-income-report.php"><i class="fa fa-file-o menu-icon"></i> INCOME REPORT</a>
                            <div class="clearfix"></div>
                        </li>
                               
                           
                        
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-file-o menu-icon"></i> EXPENSE REPORTS <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li>							
                                    <a href="cashier-expense-lecturer-report.php"><i class="fa fa-reort"></i>Based on Lecturers</a>
                                </li>
                                <li>
                                    <a href="cashier-expense-subject-report.php"><i class="fa fa-report"></i>Based on Subjects</a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-file-o menu-icon"></i> FINAL REPORTS <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="cashier-profit-statement-report.php"><i class="fa fa-report"></i>Profit/Loss Statement</a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </li>	
				</ul>
                       
			</div>