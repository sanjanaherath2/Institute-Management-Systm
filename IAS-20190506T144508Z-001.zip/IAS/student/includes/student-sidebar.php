<div class="sidebar-nav-wrapper" id="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li>
						<a href="student-dashboard.php"><i class="fa fa-home menu-icon"></i> HOME</a>
					</li>
                    <li>
						<a href="student-attendance.php"><i class="fa fa-bar-chart menu-icon"></i> MY ATTENDANCE</a>
					</li>
					<li>
						<a href="student-fees-payments.php"><i class="fa fa-money menu-icon"></i> MY FEE PAYMENTS</a>
					</li>
                    <li>
						<a href="student-tutes-download.php"><i class="fa fa-bar-chart menu-icon"></i> MY TUTES</a>
					</li>
				</ul>
</div>