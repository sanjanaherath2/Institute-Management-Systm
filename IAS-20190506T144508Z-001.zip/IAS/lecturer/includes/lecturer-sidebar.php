<div class="sidebar-nav-wrapper" id="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li>
						<a href="lecturer-dashboard.php"><i class="fa fa-home menu-icon"></i> HOME</a>
					</li>
					<li>
						<a href="lecturer-payments.php"><i class="fa fa-home menu-icon"></i> LECTURER PAYMENTS</a>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<i class="fa fa-file-code-o menu-icon"></i> LECTURE SCHEDULE <span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li>							
								<a href="lecturer-schedule.php"><i class="fa fa-caret-right"></i> VIEW</a>
							</li>
							<li>
								<a href="#"><i class="fa fa-caret-right"></i> RE-SCHEDULE</a>
							</li>
						</ul>
						<div class="clearfix"></div>
					</li>
					<li>
						<a href="lecturer-message.php"><i class="fa fa-envelope menu-icon"></i> MESSAGES</a>
					</li>
				</ul>
</div>