<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=unicode"/>
        <meta content="CoffeeCup HTML Editor (www.coffeecup.com)" name="generator"/>
    </head>
    <body>

<form method="post" action="test-submit.php">
     <input type="date" name="date">
     <input type="submit">
</form>

    </body>
</html>